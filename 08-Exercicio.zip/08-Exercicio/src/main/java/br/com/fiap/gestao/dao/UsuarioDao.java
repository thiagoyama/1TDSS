package br.com.fiap.gestao.dao;

import br.com.fiap.gestao.model.Usuario;

public class UsuarioDao {

	public void cadastrar(Usuario usuario) {
		
	}
	
}